﻿
namespace BookSwap_Lab2
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lstKurser = new System.Windows.Forms.ListBox();
            this.lstAnnonser = new System.Windows.Forms.ListBox();
            this.btnLäggTillKurs = new System.Windows.Forms.Button();
            this.btnUppdateraKurs = new System.Windows.Forms.Button();
            this.btnTaBortKurs = new System.Windows.Forms.Button();
            this.btnModereraAnnons = new System.Windows.Forms.Button();
            this.txtKurskod = new System.Windows.Forms.TextBox();
            this.txtKursnamn = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(599, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "BookSwap - Administration";
            // 
            // lstKurser
            // 
            this.lstKurser.FormattingEnabled = true;
            this.lstKurser.ItemHeight = 16;
            this.lstKurser.Location = new System.Drawing.Point(634, 72);
            this.lstKurser.Name = "lstKurser";
            this.lstKurser.Size = new System.Drawing.Size(120, 36);
            this.lstKurser.TabIndex = 1;
            // 
            // lstAnnonser
            // 
            this.lstAnnonser.FormattingEnabled = true;
            this.lstAnnonser.ItemHeight = 16;
            this.lstAnnonser.Location = new System.Drawing.Point(634, 198);
            this.lstAnnonser.Name = "lstAnnonser";
            this.lstAnnonser.Size = new System.Drawing.Size(120, 84);
            this.lstAnnonser.TabIndex = 2;
            // 
            // btnLäggTillKurs
            // 
            this.btnLäggTillKurs.Location = new System.Drawing.Point(348, 177);
            this.btnLäggTillKurs.Name = "btnLäggTillKurs";
            this.btnLäggTillKurs.Size = new System.Drawing.Size(109, 40);
            this.btnLäggTillKurs.TabIndex = 3;
            this.btnLäggTillKurs.Text = "Lägg till kurs";
            this.btnLäggTillKurs.UseVisualStyleBackColor = true;
            this.btnLäggTillKurs.Click += new System.EventHandler(this.btnLäggTillKurs_Click);
            // 
            // btnUppdateraKurs
            // 
            this.btnUppdateraKurs.Location = new System.Drawing.Point(338, 247);
            this.btnUppdateraKurs.Name = "btnUppdateraKurs";
            this.btnUppdateraKurs.Size = new System.Drawing.Size(131, 35);
            this.btnUppdateraKurs.TabIndex = 4;
            this.btnUppdateraKurs.Text = "Uppdatera kurs";
            this.btnUppdateraKurs.UseVisualStyleBackColor = true;
            this.btnUppdateraKurs.Click += new System.EventHandler(this.btnUppdateraKurs_Click);
            // 
            // btnTaBortKurs
            // 
            this.btnTaBortKurs.Location = new System.Drawing.Point(338, 320);
            this.btnTaBortKurs.Name = "btnTaBortKurs";
            this.btnTaBortKurs.Size = new System.Drawing.Size(122, 35);
            this.btnTaBortKurs.TabIndex = 5;
            this.btnTaBortKurs.Text = "Ta bort kurs";
            this.btnTaBortKurs.UseVisualStyleBackColor = true;
            this.btnTaBortKurs.Click += new System.EventHandler(this.btnTaBortKurs_Click);
            // 
            // btnModereraAnnons
            // 
            this.btnModereraAnnons.Location = new System.Drawing.Point(634, 333);
            this.btnModereraAnnons.Name = "btnModereraAnnons";
            this.btnModereraAnnons.Size = new System.Drawing.Size(137, 69);
            this.btnModereraAnnons.TabIndex = 6;
            this.btnModereraAnnons.Text = "Ta bort annons";
            this.btnModereraAnnons.UseVisualStyleBackColor = true;
            this.btnModereraAnnons.Click += new System.EventHandler(this.btnModereraAnnons_Click_1);
            // 
            // txtKurskod
            // 
            this.txtKurskod.Location = new System.Drawing.Point(348, 385);
            this.txtKurskod.Name = "txtKurskod";
            this.txtKurskod.Size = new System.Drawing.Size(100, 22);
            this.txtKurskod.TabIndex = 7;
            // 
            // txtKursnamn
            // 
            this.txtKursnamn.Location = new System.Drawing.Point(348, 449);
            this.txtKursnamn.Name = "txtKursnamn";
            this.txtKursnamn.Size = new System.Drawing.Size(100, 22);
            this.txtKursnamn.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(217, 388);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Kurskod:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(216, 453);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Kursnamn:";
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1399, 718);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtKursnamn);
            this.Controls.Add(this.txtKurskod);
            this.Controls.Add(this.btnModereraAnnons);
            this.Controls.Add(this.btnTaBortKurs);
            this.Controls.Add(this.btnUppdateraKurs);
            this.Controls.Add(this.btnLäggTillKurs);
            this.Controls.Add(this.lstAnnonser);
            this.Controls.Add(this.lstKurser);
            this.Controls.Add(this.label1);
            this.Name = "FormAdmin";
            this.Text = "FormAdmin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstKurser;
        private System.Windows.Forms.ListBox lstAnnonser;
        private System.Windows.Forms.Button btnLäggTillKurs;
        private System.Windows.Forms.Button btnUppdateraKurs;
        private System.Windows.Forms.Button btnTaBortKurs;
        private System.Windows.Forms.Button btnModereraAnnons;
        private System.Windows.Forms.TextBox txtKurskod;
        private System.Windows.Forms.TextBox txtKursnamn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}