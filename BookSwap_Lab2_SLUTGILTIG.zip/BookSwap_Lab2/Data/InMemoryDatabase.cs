﻿using System;
using System.Collections.Generic;
using BookSwap_Lab2.Models;

namespace BookSwap_Lab2.Data
{
    public class InMemoryDatabase
    {
        private List<Student> studenter;
        private List<Administratör> administratörer;
        private List<Annons> annonser;
        private List<Kurs> kurser;
        private List<Affär> affärer;

        public InMemoryDatabase()
        {
            studenter = new List<Student>();
            administratörer = new List<Administratör>();
            annonser = new List<Annons>();
            kurser = new List<Kurs>();
            affärer = new List<Affär>();

            Seed();
        }

        public List<Student> Studenter => studenter;
        public List<Administratör> Administratörer => administratörer;
        public List<Annons> Annonser => annonser;
        public List<Kurs> Kurser => kurser;
        public List<Affär> Affärer => affärer;

        public void LäggTillStudent(Student student)
        {
            studenter.Add(student);
        }

        public void LäggTillAnnons(Annons annons)
        {
            annonser.Add(annons);
        }

        public void LäggTillAffär(Affär affär)
        {
            affärer.Add(affär);
        }

        public void LäggTillKurs(Kurs kurs)
        {
            kurser.Add(kurs);
        }

        public void Seed()
        {
            Kurs kurs1 = new Kurs(
                "C1OB1B",
                "Objektorienterad systemutveckling");

            Kurs kurs2 = new Kurs(
                "NDA01G",
                "Databasteknik");

            kurser.Add(kurs1);
            kurser.Add(kurs2);

            Student student1 = new Student(
                1,
                "Shakir",
                "Mohamed",
                "shakir@student.se",
                "0701111111",
                "1234");

            Student student2 = new Student(
                2,
                "Erik",
                "Eriksson",
                "erik@student.se",
                "0702222222",
                "1234");

            studenter.Add(student1);
            studenter.Add(student2);

            Administratör admin = new Administratör(
                1,
                "Admin",
                "admin@bookswap.se",
                "admin123");

            administratörer.Add(admin);

            Kursbok kursbok = new Kursbok(
                1,
                "C# Programming",
                "Bra skick",
                250m,
                DateTime.Now,
                student1,
                kurs1,
                "9781234567890",
                "Exempelförfattare",
                "3");

            Kompendium kompendium = new Kompendium(
                2,
                "Databasteknik Kompendium",
                "Mycket bra skick",
                150m,
                DateTime.Now,
                student2,
                kurs2,
                120,
                2026);

            annonser.Add(kursbok);
            annonser.Add(kompendium);
        }
    }
}