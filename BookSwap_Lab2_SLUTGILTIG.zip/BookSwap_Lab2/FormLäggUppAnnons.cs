﻿using System;
using System.Windows.Forms;
using BookSwap_Lab2.Service;
using BookSwap_Lab2.Models;

namespace BookSwap_Lab2
{
    public partial class FormLäggUppAnnons : Form
    {
        private BookSwapService service;
        private Student inloggadStudent;

        public FormLäggUppAnnons(
            BookSwapService service,
            Student inloggadStudent)
        {
            InitializeComponent();

            this.service = service;
            this.inloggadStudent = inloggadStudent;

            cmbAnnonstyp.Items.Add("Kursbok");
            cmbAnnonstyp.Items.Add("Kompendium");
            cmbAnnonstyp.Items.Add("DigitalResurs");

            cmbKurs.DataSource = service.HämtaKurser();
            cmbKurs.DisplayMember = "Namn";
        }

        private void btnSparaAnnons_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitel.Text) ||
                string.IsNullOrWhiteSpace(txtSkick.Text) ||
                string.IsNullOrWhiteSpace(txtPris.Text) ||
                cmbKurs.SelectedItem == null ||
                cmbAnnonstyp.SelectedItem == null)
            {
                MessageBox.Show("Fyll i alla fält.");
                return;
            }

            if (!decimal.TryParse(txtPris.Text, out decimal pris) ||
                pris < 0)
            {
                MessageBox.Show("Ange ett giltigt pris.");
                return;
            }

            Kurs valdKurs = cmbKurs.SelectedItem as Kurs;

            if (valdKurs == null)
            {
                MessageBox.Show("Välj en kurs.");
                return;
            }

            int annonsId = service.NästaAnnonsId();
            string titel = txtTitel.Text.Trim();
            string skick = txtSkick.Text.Trim();
            DateTime datum = DateTime.Now;

            Annons nyAnnons;

            if (cmbAnnonstyp.SelectedItem.ToString() == "Kursbok")
            {
                nyAnnons = new Kursbok(
                    annonsId,
                    titel,
                    skick,
                    pris,
                    datum,
                    inloggadStudent,
                    valdKurs,
                    "Ej angivet",
                    "Ej angiven",
                    "Ej angiven");
            }
            else if (cmbAnnonstyp.SelectedItem.ToString() == "Kompendium")
            {
                nyAnnons = new Kompendium(
                    annonsId,
                    titel,
                    skick,
                    pris,
                    datum,
                    inloggadStudent,
                    valdKurs,
                    0,
                    DateTime.Now.Year);
            }
            else
            {
                nyAnnons = new DigitalResurs(
                    annonsId,
                    titel,
                    skick,
                    pris,
                    datum,
                    inloggadStudent,
                    valdKurs,
                    "PDF",
                    "Digital leverans");
            }

            service.LäggUppAnnons(nyAnnons);

            MessageBox.Show("Annonsen har lagts upp!");

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}