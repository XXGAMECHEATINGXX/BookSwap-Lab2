﻿
namespace BookSwap_Lab2
{
    partial class FormLäggUppAnnons
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRubrik = new System.Windows.Forms.Label();
            this.lblTitel = new System.Windows.Forms.Label();
            this.lblSkick = new System.Windows.Forms.Label();
            this.lblPris = new System.Windows.Forms.Label();
            this.lblKurs = new System.Windows.Forms.Label();
            this.lblAnnonstyp = new System.Windows.Forms.Label();
            this.txtTitel = new System.Windows.Forms.ComboBox();
            this.txtSkick = new System.Windows.Forms.ComboBox();
            this.txtPris = new System.Windows.Forms.ComboBox();
            this.cmbKurs = new System.Windows.Forms.ComboBox();
            this.cmbAnnonstyp = new System.Windows.Forms.ComboBox();
            this.btnSparaAnnons = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRubrik
            // 
            this.lblRubrik.AutoSize = true;
            this.lblRubrik.Location = new System.Drawing.Point(217, 115);
            this.lblRubrik.Name = "lblRubrik";
            this.lblRubrik.Size = new System.Drawing.Size(119, 17);
            this.lblRubrik.TabIndex = 0;
            this.lblRubrik.Text = "Lägg upp annons";
            // 
            // lblTitel
            // 
            this.lblTitel.AutoSize = true;
            this.lblTitel.Location = new System.Drawing.Point(217, 181);
            this.lblTitel.Name = "lblTitel";
            this.lblTitel.Size = new System.Drawing.Size(39, 17);
            this.lblTitel.TabIndex = 1;
            this.lblTitel.Text = "Titel:";
            // 
            // lblSkick
            // 
            this.lblSkick.AutoSize = true;
            this.lblSkick.Location = new System.Drawing.Point(217, 257);
            this.lblSkick.Name = "lblSkick";
            this.lblSkick.Size = new System.Drawing.Size(45, 17);
            this.lblSkick.TabIndex = 2;
            this.lblSkick.Text = "Skick:";
            // 
            // lblPris
            // 
            this.lblPris.AutoSize = true;
            this.lblPris.Location = new System.Drawing.Point(217, 327);
            this.lblPris.Name = "lblPris";
            this.lblPris.Size = new System.Drawing.Size(36, 17);
            this.lblPris.TabIndex = 3;
            this.lblPris.Text = "Pris:";
            // 
            // lblKurs
            // 
            this.lblKurs.AutoSize = true;
            this.lblKurs.Location = new System.Drawing.Point(217, 397);
            this.lblKurs.Name = "lblKurs";
            this.lblKurs.Size = new System.Drawing.Size(41, 17);
            this.lblKurs.TabIndex = 4;
            this.lblKurs.Text = "Kurs:";
            // 
            // lblAnnonstyp
            // 
            this.lblAnnonstyp.AutoSize = true;
            this.lblAnnonstyp.Location = new System.Drawing.Point(217, 463);
            this.lblAnnonstyp.Name = "lblAnnonstyp";
            this.lblAnnonstyp.Size = new System.Drawing.Size(79, 17);
            this.lblAnnonstyp.TabIndex = 5;
            this.lblAnnonstyp.Text = "Annonstyp:";
            // 
            // txtTitel
            // 
            this.txtTitel.FormattingEnabled = true;
            this.txtTitel.Location = new System.Drawing.Point(355, 181);
            this.txtTitel.Name = "txtTitel";
            this.txtTitel.Size = new System.Drawing.Size(121, 24);
            this.txtTitel.TabIndex = 7;
            // 
            // txtSkick
            // 
            this.txtSkick.FormattingEnabled = true;
            this.txtSkick.Location = new System.Drawing.Point(355, 257);
            this.txtSkick.Name = "txtSkick";
            this.txtSkick.Size = new System.Drawing.Size(121, 24);
            this.txtSkick.TabIndex = 8;
            // 
            // txtPris
            // 
            this.txtPris.FormattingEnabled = true;
            this.txtPris.Location = new System.Drawing.Point(355, 327);
            this.txtPris.Name = "txtPris";
            this.txtPris.Size = new System.Drawing.Size(121, 24);
            this.txtPris.TabIndex = 9;
            // 
            // cmbKurs
            // 
            this.cmbKurs.FormattingEnabled = true;
            this.cmbKurs.Location = new System.Drawing.Point(355, 409);
            this.cmbKurs.Name = "cmbKurs";
            this.cmbKurs.Size = new System.Drawing.Size(121, 24);
            this.cmbKurs.TabIndex = 10;
            // 
            // cmbAnnonstyp
            // 
            this.cmbAnnonstyp.FormattingEnabled = true;
            this.cmbAnnonstyp.Location = new System.Drawing.Point(355, 472);
            this.cmbAnnonstyp.Name = "cmbAnnonstyp";
            this.cmbAnnonstyp.Size = new System.Drawing.Size(121, 24);
            this.cmbAnnonstyp.TabIndex = 11;
            // 
            // btnSparaAnnons
            // 
            this.btnSparaAnnons.Location = new System.Drawing.Point(374, 524);
            this.btnSparaAnnons.Name = "btnSparaAnnons";
            this.btnSparaAnnons.Size = new System.Drawing.Size(102, 67);
            this.btnSparaAnnons.TabIndex = 12;
            this.btnSparaAnnons.Text = "Spara annons";
            this.btnSparaAnnons.UseVisualStyleBackColor = true;
            this.btnSparaAnnons.Click += new System.EventHandler(this.btnSparaAnnons_Click);
            // 
            // FormLäggUppAnnons
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 603);
            this.Controls.Add(this.btnSparaAnnons);
            this.Controls.Add(this.cmbAnnonstyp);
            this.Controls.Add(this.cmbKurs);
            this.Controls.Add(this.txtPris);
            this.Controls.Add(this.txtSkick);
            this.Controls.Add(this.txtTitel);
            this.Controls.Add(this.lblAnnonstyp);
            this.Controls.Add(this.lblKurs);
            this.Controls.Add(this.lblPris);
            this.Controls.Add(this.lblSkick);
            this.Controls.Add(this.lblTitel);
            this.Controls.Add(this.lblRubrik);
            this.Name = "FormLäggUppAnnons";
            this.Text = "FormLäggUppAnnons";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRubrik;
        private System.Windows.Forms.Label lblTitel;
        private System.Windows.Forms.Label lblSkick;
        private System.Windows.Forms.Label lblPris;
        private System.Windows.Forms.Label lblKurs;
        private System.Windows.Forms.Label lblAnnonstyp;
        private System.Windows.Forms.ComboBox txtTitel;
        private System.Windows.Forms.ComboBox txtSkick;
        private System.Windows.Forms.ComboBox txtPris;
        private System.Windows.Forms.ComboBox cmbKurs;
        private System.Windows.Forms.ComboBox cmbAnnonstyp;
        private System.Windows.Forms.Button btnSparaAnnons;
    }
}