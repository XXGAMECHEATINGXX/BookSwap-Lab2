﻿using System.Windows.Forms;
using BookSwap_Lab2.Service;
using BookSwap_Lab2.Models;

namespace BookSwap_Lab2
{
    public partial class FormHuvudmeny : Form
    {
        private BookSwapService service;
        private Student inloggadStudent;

        public FormHuvudmeny(
            BookSwapService service,
            Student inloggadStudent)
        {
            InitializeComponent();

            this.service = service;
            this.inloggadStudent = inloggadStudent;
        }

        private void btnVisaAnnonser_Click(
            object sender,
            System.EventArgs e)
        {
            lstAnnonser.Items.Clear();

            foreach (Annons annons in service.HämtaTillgängligaAnnonser())
            {
                lstAnnonser.Items.Add(annons);
            }
        }

        private void Sök_Click(
            object sender,
            System.EventArgs e)
        {
            lstAnnonser.Items.Clear();

            foreach (Annons annons in service.SökAnnonser(txtSök.Text))
            {
                lstAnnonser.Items.Add(annons);
            }
        }

        private void button1_Click(
            object sender,
            System.EventArgs e)
        {
            Annons valdAnnons = lstAnnonser.SelectedItem as Annons;

            if (valdAnnons == null)
            {
                MessageBox.Show("Välj en annons först.");
                return;
            }

            Affär affär = service.ReserveraAnnons(
                valdAnnons,
                inloggadStudent);

            if (affär != null)
            {
                MessageBox.Show("Annonsen har reserverats!");

                lstAnnonser.Items.Clear();

                foreach (Annons annons in service.HämtaTillgängligaAnnonser())
                {
                    lstAnnonser.Items.Add(annons);
                }
            }
            else
            {
                MessageBox.Show("Annonsen kunde inte reserveras.");
            }
        }

        private void btnLäggUppAnnons_Click(
            object sender,
            System.EventArgs e)
        {
            using (FormLäggUppAnnons formulär =
                new FormLäggUppAnnons(service, inloggadStudent))
            {
                if (formulär.ShowDialog() == DialogResult.OK)
                {
                    lstAnnonser.Items.Clear();

                    foreach (Annons annons in service.HämtaTillgängligaAnnonser())
                    {
                        lstAnnonser.Items.Add(annons);
                    }
                }
            }
        }

        private void btnUppdateraAnnons_Click(
            object sender,
            System.EventArgs e)
        {
            Annons valdAnnons = lstAnnonser.SelectedItem as Annons;

            if (valdAnnons == null)
            {
                MessageBox.Show("Välj en annons först.");
                return;
            }

            if (valdAnnons.Säljare != inloggadStudent)
            {
                MessageBox.Show(
                    "Du kan bara uppdatera dina egna annonser.");
                return;
            }

            using (FormUppdateraAnnons formulär =
                new FormUppdateraAnnons(
                    service,
                    inloggadStudent,
                    valdAnnons))
            {
                if (formulär.ShowDialog() == DialogResult.OK)
                {
                    lstAnnonser.Items.Clear();

                    foreach (Annons annons in service.HämtaTillgängligaAnnonser())
                    {
                        lstAnnonser.Items.Add(annons);
                    }
                }
            }
        }

        private void btnTaBortAnnons_Click(
            object sender,
            System.EventArgs e)
        {
            Annons valdAnnons = lstAnnonser.SelectedItem as Annons;

            if (valdAnnons == null)
            {
                MessageBox.Show("Välj en annons först.");
                return;
            }

            bool lyckades = service.TaBortAnnons(
                valdAnnons,
                inloggadStudent);

            if (lyckades)
            {
                MessageBox.Show("Annonsen har tagits bort!");

                lstAnnonser.Items.Clear();

                foreach (Annons annons in service.HämtaTillgängligaAnnonser())
                {
                    lstAnnonser.Items.Add(annons);
                }
            }
            else
            {
                MessageBox.Show(
                    "Du kan bara ta bort dina egna annonser.");
            }
        }
    }
}