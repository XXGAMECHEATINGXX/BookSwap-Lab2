﻿
namespace BookSwap_Lab2
{
    partial class FormHuvudmeny
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnVisaAnnonser = new System.Windows.Forms.Button();
            this.lstAnnonser = new System.Windows.Forms.ListBox();
            this.txtSök = new System.Windows.Forms.TextBox();
            this.btnSök = new System.Windows.Forms.Button();
            this.btnReservera = new System.Windows.Forms.Button();
            this.btnLäggUppAnnons = new System.Windows.Forms.Button();
            this.btnUppdateraAnnons = new System.Windows.Forms.Button();
            this.btnTaBortAnnons = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(236, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "BookSwap – Huvudmeny";
            // 
            // btnVisaAnnonser
            // 
            this.btnVisaAnnonser.Location = new System.Drawing.Point(275, 192);
            this.btnVisaAnnonser.Name = "btnVisaAnnonser";
            this.btnVisaAnnonser.Size = new System.Drawing.Size(75, 23);
            this.btnVisaAnnonser.TabIndex = 1;
            this.btnVisaAnnonser.Text = "Visa annonser";
            this.btnVisaAnnonser.UseVisualStyleBackColor = true;
            this.btnVisaAnnonser.Click += new System.EventHandler(this.btnVisaAnnonser_Click);
            // 
            // lstAnnonser
            // 
            this.lstAnnonser.FormattingEnabled = true;
            this.lstAnnonser.ItemHeight = 16;
            this.lstAnnonser.Location = new System.Drawing.Point(266, 274);
            this.lstAnnonser.Name = "lstAnnonser";
            this.lstAnnonser.Size = new System.Drawing.Size(120, 84);
            this.lstAnnonser.TabIndex = 2;
            // 
            // txtSök
            // 
            this.txtSök.Location = new System.Drawing.Point(275, 234);
            this.txtSök.Name = "txtSök";
            this.txtSök.Size = new System.Drawing.Size(100, 22);
            this.txtSök.TabIndex = 3;
            // 
            // btnSök
            // 
            this.btnSök.Location = new System.Drawing.Point(439, 232);
            this.btnSök.Name = "btnSök";
            this.btnSök.Size = new System.Drawing.Size(75, 23);
            this.btnSök.TabIndex = 4;
            this.btnSök.Text = "Sök";
            this.btnSök.UseVisualStyleBackColor = true;
            this.btnSök.Click += new System.EventHandler(this.Sök_Click);
            // 
            // btnReservera
            // 
            this.btnReservera.Location = new System.Drawing.Point(265, 381);
            this.btnReservera.Name = "btnReservera";
            this.btnReservera.Size = new System.Drawing.Size(121, 63);
            this.btnReservera.TabIndex = 5;
            this.btnReservera.Text = "Lägg upp annons";
            this.btnReservera.UseVisualStyleBackColor = true;
            this.btnReservera.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLäggUppAnnons
            // 
            this.btnLäggUppAnnons.Location = new System.Drawing.Point(254, 461);
            this.btnLäggUppAnnons.Name = "btnLäggUppAnnons";
            this.btnLäggUppAnnons.Size = new System.Drawing.Size(143, 65);
            this.btnLäggUppAnnons.TabIndex = 6;
            this.btnLäggUppAnnons.Text = "Lägg upp annons";
            this.btnLäggUppAnnons.UseVisualStyleBackColor = true;
            this.btnLäggUppAnnons.Click += new System.EventHandler(this.btnLäggUppAnnons_Click);
            // 
            // btnUppdateraAnnons
            // 
            this.btnUppdateraAnnons.Location = new System.Drawing.Point(287, 549);
            this.btnUppdateraAnnons.Name = "btnUppdateraAnnons";
            this.btnUppdateraAnnons.Size = new System.Drawing.Size(75, 65);
            this.btnUppdateraAnnons.TabIndex = 7;
            this.btnUppdateraAnnons.Text = "Uppdatera annons";
            this.btnUppdateraAnnons.UseVisualStyleBackColor = true;
            this.btnUppdateraAnnons.Click += new System.EventHandler(this.btnUppdateraAnnons_Click);
            // 
            // btnTaBortAnnons
            // 
            this.btnTaBortAnnons.Location = new System.Drawing.Point(254, 631);
            this.btnTaBortAnnons.Name = "btnTaBortAnnons";
            this.btnTaBortAnnons.Size = new System.Drawing.Size(157, 44);
            this.btnTaBortAnnons.TabIndex = 8;
            this.btnTaBortAnnons.Text = "Ta bort annons";
            this.btnTaBortAnnons.UseVisualStyleBackColor = true;
            this.btnTaBortAnnons.Click += new System.EventHandler(this.btnTaBortAnnons_Click);
            // 
            // FormHuvudmeny
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1389, 687);
            this.Controls.Add(this.btnTaBortAnnons);
            this.Controls.Add(this.btnUppdateraAnnons);
            this.Controls.Add(this.btnLäggUppAnnons);
            this.Controls.Add(this.btnReservera);
            this.Controls.Add(this.btnSök);
            this.Controls.Add(this.txtSök);
            this.Controls.Add(this.lstAnnonser);
            this.Controls.Add(this.btnVisaAnnonser);
            this.Controls.Add(this.label1);
            this.Name = "FormHuvudmeny";
            this.Text = "FormHuvudmeny";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVisaAnnonser;
        private System.Windows.Forms.ListBox lstAnnonser;
        private System.Windows.Forms.TextBox txtSök;
        private System.Windows.Forms.Button btnSök;
        private System.Windows.Forms.Button btnReservera;
        private System.Windows.Forms.Button btnLäggUppAnnons;
        private System.Windows.Forms.Button btnUppdateraAnnons;
        private System.Windows.Forms.Button btnTaBortAnnons;
    }
}