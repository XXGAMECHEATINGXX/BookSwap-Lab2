﻿using System;
using System.Windows.Forms;
using BookSwap_Lab2.Models;
using BookSwap_Lab2.Service;

namespace BookSwap_Lab2
{
    public partial class FormRegistrera : Form
    {
        private BookSwapService service;

        public FormRegistrera(BookSwapService service)
        {
            InitializeComponent();

            this.service = service;

            txtLösenord.UseSystemPasswordChar = true;
        }

        private void btnRegistrera_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFörnamn.Text) ||
                string.IsNullOrWhiteSpace(txtEfternamn.Text) ||
                string.IsNullOrWhiteSpace(txtEpost.Text) ||
                string.IsNullOrWhiteSpace(txtTelefon.Text) ||
                string.IsNullOrWhiteSpace(txtLösenord.Text))
            {
                MessageBox.Show("Fyll i alla fält.");
                return;
            }

            int studentId = service.NästaStudentId();

            Student nyStudent = new Student(
                studentId,
                txtFörnamn.Text.Trim(),
                txtEfternamn.Text.Trim(),
                txtEpost.Text.Trim(),
                txtTelefon.Text.Trim(),
                txtLösenord.Text);

            service.RegistreraStudent(nyStudent);

            MessageBox.Show("Kontot har registrerats!");

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}