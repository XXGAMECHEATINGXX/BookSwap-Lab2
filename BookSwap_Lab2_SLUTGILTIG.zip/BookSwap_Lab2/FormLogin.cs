﻿using System;
using System.Windows.Forms;
using BookSwap_Lab2.Data;
using BookSwap_Lab2.Service;
using BookSwap_Lab2.Models;

namespace BookSwap_Lab2
{
    public partial class FormLogin : Form
    {
        private InMemoryDatabase db;
        private BookSwapService service;

        public FormLogin()
        {
            InitializeComponent();

            db = new InMemoryDatabase();
            service = new BookSwapService(db);

            txtLösenord.UseSystemPasswordChar = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Försök först logga in som student
            Student student = service.LoggaInStudent(
                txtEpost.Text,
                txtLösenord.Text);

            if (student != null)
            {
                FormHuvudmeny huvudmeny =
                    new FormHuvudmeny(service, student);

                huvudmeny.Show();
                this.Hide();

                return;
            }

            // Om det inte är en student, försök som administratör
            Administratör admin = service.LoggaInAdministratör(
                txtEpost.Text,
                txtLösenord.Text);

            if (admin != null)
            {
                FormAdmin adminForm =
                    new FormAdmin(service);

                adminForm.Show();
                this.Hide();

                return;
            }

            // Varken student eller administratör hittades
            MessageBox.Show("Fel e-post eller lösenord.");
        }

        private void btnRegistrera_Click(object sender, EventArgs e)
        {
            using (FormRegistrera formulär =
                new FormRegistrera(service))
            {
                formulär.ShowDialog();
            }
        }
    }
}