﻿using System;
using System.Windows.Forms;
using BookSwap_Lab2.Models;
using BookSwap_Lab2.Service;

namespace BookSwap_Lab2
{
    public partial class FormUppdateraAnnons : Form
    {
        private BookSwapService service;
        private Student inloggadStudent;
        private Annons annons;

        public FormUppdateraAnnons(
            BookSwapService service,
            Student inloggadStudent,
            Annons annons)
        {
            InitializeComponent();

            this.service = service;
            this.inloggadStudent = inloggadStudent;
            this.annons = annons;

            // Fyll kurslistan
            cmbKurs.DataSource = service.HämtaKurser();
            cmbKurs.DisplayMember = "Namn";

            // Visa annonsens nuvarande uppgifter
            txtTitel.Text = annons.Titel;
            txtSkick.Text = annons.Skick;
            txtPris.Text = annons.Pris.ToString();
            cmbKurs.SelectedItem = annons.Kurs;
        }

        private void btnSpara_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitel.Text) ||
                string.IsNullOrWhiteSpace(txtSkick.Text) ||
                string.IsNullOrWhiteSpace(txtPris.Text) ||
                cmbKurs.SelectedItem == null)
            {
                MessageBox.Show("Fyll i alla fält.");
                return;
            }

            if (!decimal.TryParse(txtPris.Text, out decimal pris) ||
                pris < 0)
            {
                MessageBox.Show("Ange ett giltigt pris.");
                return;
            }

            Kurs valdKurs = cmbKurs.SelectedItem as Kurs;

            bool lyckades = service.UppdateraAnnons(
                annons,
                inloggadStudent,
                txtTitel.Text.Trim(),
                txtSkick.Text.Trim(),
                pris,
                valdKurs);

            if (lyckades)
            {
                MessageBox.Show("Annonsen har uppdaterats!");

                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show(
                    "Du kan bara uppdatera dina egna annonser.");
            }
        }
    }
}