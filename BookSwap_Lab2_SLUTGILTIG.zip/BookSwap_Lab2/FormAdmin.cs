﻿using System;
using System.Windows.Forms;
using BookSwap_Lab2.Models;
using BookSwap_Lab2.Service;

namespace BookSwap_Lab2
{
    public partial class FormAdmin : Form
    {
        private BookSwapService service;

        public FormAdmin(BookSwapService service)
        {
            InitializeComponent();

            this.service = service;

            UppdateraListor();
        }

        private void UppdateraListor()
        {
            lstKurser.Items.Clear();

            foreach (Kurs kurs in service.HämtaKurser())
            {
                lstKurser.Items.Add(kurs);
            }

            lstAnnonser.Items.Clear();

            foreach (Annons annons in service.HämtaTillgängligaAnnonser())
            {
                lstAnnonser.Items.Add(annons);
            }
        }

        private void btnLäggTillKurs_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtKurskod.Text) ||
                string.IsNullOrWhiteSpace(txtKursnamn.Text))
            {
                MessageBox.Show("Fyll i kurskod och kursnamn.");
                return;
            }

            Kurs nyKurs = new Kurs(
                txtKurskod.Text.Trim(),
                txtKursnamn.Text.Trim());

            service.LäggTillKurs(nyKurs);

            MessageBox.Show("Kursen har lagts till!");

            txtKurskod.Clear();
            txtKursnamn.Clear();

            UppdateraListor();
        }

        private void btnUppdateraKurs_Click(object sender, EventArgs e)
        {
            Kurs valdKurs = lstKurser.SelectedItem as Kurs;

            if (valdKurs == null)
            {
                MessageBox.Show("Välj en kurs först.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtKurskod.Text) ||
                string.IsNullOrWhiteSpace(txtKursnamn.Text))
            {
                MessageBox.Show("Fyll i kurskod och kursnamn.");
                return;
            }

            service.UppdateraKurs(
                valdKurs,
                txtKurskod.Text.Trim(),
                txtKursnamn.Text.Trim());

            MessageBox.Show("Kursen har uppdaterats!");

            txtKurskod.Clear();
            txtKursnamn.Clear();

            UppdateraListor();
        }

        private void btnTaBortKurs_Click(object sender, EventArgs e)
        {
            Kurs valdKurs = lstKurser.SelectedItem as Kurs;

            if (valdKurs == null)
            {
                MessageBox.Show("Välj en kurs först.");
                return;
            }

            service.TaBortKurs(valdKurs);

            MessageBox.Show("Kursen har tagits bort!");

            UppdateraListor();
        }

        private void btnModereraAnnons_Click_1(object sender, EventArgs e)
        {
            Annons valdAnnons = lstAnnonser.SelectedItem as Annons;

            if (valdAnnons == null)
            {
                MessageBox.Show("Välj en annons först.");
                return;
            }

            service.ModereraAnnons(valdAnnons);

            MessageBox.Show("Annonsen har tagits bort!");

            UppdateraListor();
        }
    }
}