﻿using System;

namespace BookSwap_Lab2.Models
{
    public abstract class Annons
    {
        private int annonsId;
        private string titel;
        private string skick;
        private decimal pris;
        private DateTime publiceringsdatum;
        private AnnonsStatus status;
        private Student säljare;
        private Kurs kurs;

        protected Annons(
            int annonsId,
            string titel,
            string skick,
            decimal pris,
            DateTime publiceringsdatum,
            Student säljare,
            Kurs kurs)
        {
            this.annonsId = annonsId;
            this.titel = titel;
            this.skick = skick;
            this.pris = pris;
            this.publiceringsdatum = publiceringsdatum;
            this.status = AnnonsStatus.TillSalu;
            this.säljare = säljare;
            this.kurs = kurs;
        }

        public int AnnonsId => annonsId;
        public string Titel => titel;
        public string Skick => skick;
        public decimal Pris => pris;
        public DateTime Publiceringsdatum => publiceringsdatum;
        public AnnonsStatus Status => status;
        public Student Säljare => säljare;
        public Kurs Kurs => kurs;

        public bool ÄrTillgänglig()
        {
            return status == AnnonsStatus.TillSalu;
        }

        public void MarkeraReserverad()
        {
            status = AnnonsStatus.Reserverad;
        }

        public void Uppdatera(
            string titel,
            string skick,
            decimal pris,
            Kurs kurs)
        {
            this.titel = titel;
            this.skick = skick;
            this.pris = pris;
            this.kurs = kurs;
        }

        public abstract string HämtaBeskrivning();

        public override string ToString()
        {
            return HämtaBeskrivning();
        }
    }
}