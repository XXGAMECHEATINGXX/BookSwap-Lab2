﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookSwap_Lab2.Models
{
    public enum AffärStatus
    {
        Reserverad,
        Avslutad,
        Avbruten
    }
}