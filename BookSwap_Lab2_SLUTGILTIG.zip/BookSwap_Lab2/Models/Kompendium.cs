﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BookSwap_Lab2.Models
{
    public class Kompendium : Annons
    {
        private int sidantal;
        private int utgivningsår;

        public Kompendium(int annonsId, string titel, string skick,
            decimal pris, DateTime publiceringsdatum,
            Student säljare, Kurs kurs,
            int sidantal, int utgivningsår)
            : base(annonsId, titel, skick, pris,
                  publiceringsdatum, säljare, kurs)
        {
            this.sidantal = sidantal;
            this.utgivningsår = utgivningsår;
        }

        public int Sidantal => sidantal;
        public int Utgivningsår => utgivningsår;

        public override string HämtaBeskrivning()
        {
            return $"{Titel} - {sidantal} sidor, utgivningsår {utgivningsår}";
        }
    }
}