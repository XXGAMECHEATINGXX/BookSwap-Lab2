﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookSwap_Lab2.Models
{
    public class Student
    {
        private int studentId;
        private string förnamn;
        private string efternamn;
        private string epost;
        private string telefon;
        private string lösenord;

        public Student(int studentId, string förnamn, string efternamn,
            string epost, string telefon, string lösenord)
        {
            this.studentId = studentId;
            this.förnamn = förnamn;
            this.efternamn = efternamn;
            this.epost = epost;
            this.telefon = telefon;
            this.lösenord = lösenord;
        }

        public int StudentId => studentId;
        public string Förnamn => förnamn;
        public string Efternamn => efternamn;
        public string Epost => epost;
        public string Telefon => telefon;
        public string Lösenord => lösenord;
    }
}