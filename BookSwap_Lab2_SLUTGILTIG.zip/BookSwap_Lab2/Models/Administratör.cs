﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookSwap_Lab2.Models
{
    public class Administratör
    {
        private int administratörId;
        private string namn;
        private string epost;
        private string lösenord;

        public Administratör(int administratörId, string namn,
            string epost, string lösenord)
        {
            this.administratörId = administratörId;
            this.namn = namn;
            this.epost = epost;
            this.lösenord = lösenord;
        }

        public int AdministratörId => administratörId;
        public string Namn => namn;
        public string Epost => epost;
        public string Lösenord => lösenord;
    }
}