﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BookSwap_Lab2.Models
{
    public class Kursbok : Annons
    {
        private string ISBN;
        private string författare;
        private string upplaga;

        public Kursbok(int annonsId, string titel, string skick,
            decimal pris, DateTime publiceringsdatum,
            Student säljare, Kurs kurs,
            string ISBN, string författare, string upplaga)
            : base(annonsId, titel, skick, pris,
                  publiceringsdatum, säljare, kurs)
        {
            this.ISBN = ISBN;
            this.författare = författare;
            this.upplaga = upplaga;
        }

        public string Isbn => ISBN;
        public string Författare => författare;
        public string Upplaga => upplaga;

        public override string HämtaBeskrivning()
        {
            return $"{Titel} - {författare}, upplaga {upplaga}, ISBN: {ISBN}";
        }
    }
}