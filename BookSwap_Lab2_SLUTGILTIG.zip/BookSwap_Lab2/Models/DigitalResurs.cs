﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BookSwap_Lab2.Models
{
    public class DigitalResurs : Annons
    {
        private string filformat;
        private string leveranssätt;

        public DigitalResurs(int annonsId, string titel, string skick,
            decimal pris, DateTime publiceringsdatum,
            Student säljare, Kurs kurs,
            string filformat, string leveranssätt)
            : base(annonsId, titel, skick, pris,
                  publiceringsdatum, säljare, kurs)
        {
            this.filformat = filformat;
            this.leveranssätt = leveranssätt;
        }

        public string Filformat => filformat;
        public string Leveranssätt => leveranssätt;

        public override string HämtaBeskrivning()
        {
            return $"{Titel} - {filformat}, leverans: {leveranssätt}";
        }
    }
}