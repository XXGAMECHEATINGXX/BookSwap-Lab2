﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BookSwap_Lab2.Models
{
    public class Affär
    {
        private int affärId;
        private DateTime reservationsdatum;
        private AffärStatus status;
        private Student köpare;
        private Annons annons;

        public Affär(int affärId, DateTime reservationsdatum,
            Student köpare, Annons annons)
        {
            this.affärId = affärId;
            this.reservationsdatum = reservationsdatum;
            this.status = AffärStatus.Reserverad;
            this.köpare = köpare;
            this.annons = annons;
        }

        public int AffärId => affärId;
        public DateTime Reservationsdatum => reservationsdatum;
        public AffärStatus Status => status;
        public Student Köpare => köpare;
        public Annons Annons => annons;

        public void ÄndraStatus(AffärStatus status)
        {
            this.status = status;
        }
    }
}