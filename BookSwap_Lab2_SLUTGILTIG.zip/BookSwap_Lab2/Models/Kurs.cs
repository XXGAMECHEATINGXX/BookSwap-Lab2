﻿namespace BookSwap_Lab2.Models
{
    public class Kurs
    {
        private string kod;
        private string namn;

        public Kurs(string kod, string namn)
        {
            this.kod = kod;
            this.namn = namn;
        }

        public string Kod => kod;
        public string Namn => namn;

        public void Uppdatera(string kod, string namn)
        {
            this.kod = kod;
            this.namn = namn;
        }

        public override string ToString()
        {
            return kod + " - " + namn;
        }
    }
}