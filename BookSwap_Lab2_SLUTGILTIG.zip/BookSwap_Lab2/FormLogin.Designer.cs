﻿
namespace BookSwap_Lab2
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLösenord = new System.Windows.Forms.TextBox();
            this.txtEpost = new System.Windows.Forms.TextBox();
            this.btnLoggain = new System.Windows.Forms.Button();
            this.btnRegistrera = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(450, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "E-post";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(574, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lösenord";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(276, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "BookSwap";
            // 
            // txtLösenord
            // 
            this.txtLösenord.Location = new System.Drawing.Point(408, 237);
            this.txtLösenord.Name = "txtLösenord";
            this.txtLösenord.Size = new System.Drawing.Size(100, 22);
            this.txtLösenord.TabIndex = 3;
            this.txtLösenord.UseSystemPasswordChar = true;
            // 
            // txtEpost
            // 
            this.txtEpost.Location = new System.Drawing.Point(279, 237);
            this.txtEpost.Name = "txtEpost";
            this.txtEpost.Size = new System.Drawing.Size(100, 22);
            this.txtEpost.TabIndex = 4;
            // 
            // btnLoggain
            // 
            this.btnLoggain.Location = new System.Drawing.Point(365, 302);
            this.btnLoggain.Name = "btnLoggain";
            this.btnLoggain.Size = new System.Drawing.Size(75, 50);
            this.btnLoggain.TabIndex = 5;
            this.btnLoggain.Text = "Logga in";
            this.btnLoggain.UseVisualStyleBackColor = true;
            this.btnLoggain.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRegistrera
            // 
            this.btnRegistrera.Location = new System.Drawing.Point(332, 402);
            this.btnRegistrera.Name = "btnRegistrera";
            this.btnRegistrera.Size = new System.Drawing.Size(143, 36);
            this.btnRegistrera.TabIndex = 6;
            this.btnRegistrera.Text = "Registrera konto";
            this.btnRegistrera.UseVisualStyleBackColor = true;
            this.btnRegistrera.Click += new System.EventHandler(this.btnRegistrera_Click);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRegistrera);
            this.Controls.Add(this.btnLoggain);
            this.Controls.Add(this.txtEpost);
            this.Controls.Add(this.txtLösenord);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormLogin";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLösenord;
        private System.Windows.Forms.TextBox txtEpost;
        private System.Windows.Forms.Button btnLoggain;
        private System.Windows.Forms.Button btnRegistrera;
    }
}

