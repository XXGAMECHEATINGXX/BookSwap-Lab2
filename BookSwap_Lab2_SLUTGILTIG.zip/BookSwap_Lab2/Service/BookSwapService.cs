﻿using System;
using System.Collections.Generic;
using System.Linq;
using BookSwap_Lab2.Models;
using BookSwap_Lab2.Data;

namespace BookSwap_Lab2.Service
{
    public class BookSwapService
    {
        private InMemoryDatabase db;

        public BookSwapService(InMemoryDatabase db)
        {
            this.db = db;
        }

        public void RegistreraStudent(Student student)
        {
            db.LäggTillStudent(student);
        }

        public int NästaStudentId()
        {
            if (db.Studenter.Count == 0)
            {
                return 1;
            }

            return db.Studenter.Max(
                student => student.StudentId) + 1;
        }

        public Student LoggaInStudent(string epost, string lösenord)
        {
            return db.Studenter.FirstOrDefault(
                student => student.Epost == epost &&
                           student.Lösenord == lösenord);
        }

        public Administratör LoggaInAdministratör(
            string epost, string lösenord)
        {
            return db.Administratörer.FirstOrDefault(
                admin => admin.Epost == epost &&
                         admin.Lösenord == lösenord);
        }

        public void LäggUppAnnons(Annons annons)
        {
            db.LäggTillAnnons(annons);
        }

        public List<Kurs> HämtaKurser()
        {
            return db.Kurser;
        }

        public int NästaAnnonsId()
        {
            if (db.Annonser.Count == 0)
            {
                return 1;
            }

            return db.Annonser.Max(
                annons => annons.AnnonsId) + 1;
        }

        public List<Annons> HämtaTillgängligaAnnonser()
        {
            return db.Annonser
                .Where(annons => annons.ÄrTillgänglig())
                .ToList();
        }

        public List<Annons> SökAnnonser(string sökterm)
        {
            return db.Annonser
                .Where(annons =>
                    annons.Titel.IndexOf(
                        sökterm,
                        StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        public bool UppdateraAnnons(
            Annons annons,
            Student inloggadStudent,
            string titel,
            string skick,
            decimal pris,
            Kurs kurs)
        {
            if (annons == null || inloggadStudent == null)
            {
                return false;
            }

            if (annons.Säljare != inloggadStudent)
            {
                return false;
            }

            annons.Uppdatera(titel, skick, pris, kurs);

            return true;
        }

        public bool TaBortAnnons(
            Annons annons,
            Student inloggadStudent)
        {
            if (annons == null || inloggadStudent == null)
            {
                return false;
            }

            if (annons.Säljare != inloggadStudent)
            {
                return false;
            }

            db.Annonser.Remove(annons);

            return true;
        }

        public Affär ReserveraAnnons(
            Annons annons,
            Student inloggadStudent)
        {
            if (annons == null || inloggadStudent == null)
            {
                return null;
            }

            if (!annons.ÄrTillgänglig())
            {
                return null;
            }

            if (annons.Säljare == inloggadStudent)
            {
                return null;
            }

            Affär affär = new Affär(
                db.Affärer.Count + 1,
                DateTime.Now,
                inloggadStudent,
                annons);

            annons.MarkeraReserverad();
            db.LäggTillAffär(affär);

            return affär;
        }

        public void LäggTillKurs(Kurs kurs)
        {
            db.LäggTillKurs(kurs);
        }

        public void UppdateraKurs(
    Kurs kurs,
    string kod,
    string namn)
        {
            if (kurs == null)
            {
                return;
            }

            kurs.Uppdatera(kod, namn);
        }

        public void TaBortKurs(Kurs kurs)
        {
            db.Kurser.Remove(kurs);
        }

        public void ModereraAnnons(Annons annons)
        {
            db.Annonser.Remove(annons);
        }
    }
}